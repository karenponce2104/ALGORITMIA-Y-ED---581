//Fecha:  sábado 30 Agosto 2025 
//Autor: Ana Roncal 

#ifndef LISTASIMPLEMENTEENLAZADA_LISTA_H
#define LISTASIMPLEMENTEENLAZADA_LISTA_H
#include "NodoLista.h"
struct Lista {
    NodoLista * inicio;
    NodoLista * fin;
};
#endif //LISTASIMPLEMENTEENLAZADA_LISTA_H