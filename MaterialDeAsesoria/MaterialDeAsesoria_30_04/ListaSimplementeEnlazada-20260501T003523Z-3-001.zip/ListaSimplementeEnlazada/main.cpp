//Fecha:  sábado 30 Agosto 2025 
//Autor: Ana Roncal

#include <iostream>
#include "BibliotecaLista/Lista.h"
#include "BibliotecaLista/funcionesLista.h"
using namespace std;


void fusiona(Lista &L1, Lista L2) {
    if (L1.fin->elemento.codigo < L2.inicio->elemento.codigo) {
        L1.fin->siguiente = L2.inicio;
        L1.fin = L2.fin;
    } else {
        if (L2.fin->elemento.codigo < L1.inicio->elemento.codigo) {
            L2.fin->siguiente = L1.inicio;
        } else {
            //aqui vamos a mezclar
            NodoLista *nini, *nfin;
            nini = nullptr;
            nfin = nullptr;
            while (!esListaVacia(L1) and !esListaVacia(L2)) {
                if (L1.inicio->elemento.codigo < L2.inicio->elemento.codigo) {
                    if (nini == nullptr) {
                        nini = L1.inicio;
                        nfin = L1.inicio;
                    } else {
                        nfin->siguiente = L1.inicio;
                        nfin = L1.inicio;
                    }
                    L1.inicio = L1.inicio->siguiente;
                } else if (L1.inicio->elemento.codigo > L2.inicio->elemento.codigo) {
                    if (nini == nullptr) {
                        nini = L2.inicio;
                        nfin = L2.inicio;
                    } else {
                        nfin->siguiente = L2.inicio;
                        nfin = L2.inicio;
                    }
                    L2.inicio = L2.inicio->siguiente;
                }
            }
            if (!esListaVacia(L1)) {
                nfin->siguiente = L1.inicio;
                nfin = L1.fin;
            }
            if (!esListaVacia(L2)) {
                nfin->siguiente = L2.inicio;
                nfin = L2.fin;
            }
            L1.inicio = nini;
            L1.fin = nfin;
        }
    }

}


int main(int argc, char **argv) {
    struct ElementoLista elemento{};
    struct Lista lista1, lista2;

    construir(lista1);
    construir(lista2);

    elemento.codigo = 5;
    insertarAlFinal(lista1, elemento);
    elemento.codigo = 8;
    insertarAlFinal(lista1, elemento);
    elemento.codigo = 10;
    insertarAlFinal(lista1, elemento);
    imprimir(lista1);

    elemento.codigo = 6;
    insertarAlFinal(lista2, elemento);
    elemento.codigo = 9;
    insertarAlFinal(lista2, elemento);
    elemento.codigo = 12;
    insertarAlFinal(lista2, elemento);
    elemento.codigo = 14;
    insertarAlFinal(lista2, elemento);
    imprimir(lista2);
    fusiona(lista1,lista2);
    imprimir(lista1);

    return 0;
}
